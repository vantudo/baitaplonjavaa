package utils;

public enum PopupType {
    ADD,
    EDIT
}
