package freechart;

/**
 * createAt Jan 2, 2021
 *
 * @author Đỗ Tuấn Anh <daclip26@gmail.com>
 */
public class WorkingTime {

    public int day;
    public int minus;

    public WorkingTime(int day, int minus) {
        this.day = day;
        this.minus = minus;
    }

}
